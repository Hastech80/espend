// BACKEND: index.js
 
const express = require('express');
const multer = require('multer');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const path = require('path');
const cors = require('cors');
const cookieParser = require('cookie-parser');
 
 


 
const app = express();
app.use(express.json());
app.use(cookieParser());
app.use(cors({
  origin: 'http://localhost:5173',   
  credentials: true
}));  
 

 

  const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'optismart', 
  });


  db.query(`
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(100),
      email VARCHAR(100) UNIQUE, 
      password VARCHAR(255),
      role VARCHAR(50),
      profile_image VARCHAR(255) , 
      phone VARCHAR(255) , 
      address VARCHAR(255) 
    )
  `, (err) => {
    if (err) throw err;
    console.log('Users table ensured.');
  });

  db.query(`
    CREATE TABLE IF NOT EXISTS products (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      image VARCHAR(255),
      description TEXT,
      price DECIMAL(10, 2) NOT NULL,
      discount DECIMAL(5, 2) DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `, (err) => {
    if (err) throw err;
    console.log('Products table ensured.');
  });
 
  
// Tables
db.query(`
  CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )
  `);
  
  db.query(`
  CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    announcement_id INT,
    name VARCHAR(255),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )
  `);
  
  db.query(`
  CREATE TABLE IF NOT EXISTS reactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    announcement_id INT,
    user_name VARCHAR(255),
    reaction ENUM('like','dislike')
  )
  `);
  
db.query(`  CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT,
  product_name VARCHAR(255),
  qty INT,
  user_name VARCHAR(100),
  price DECIMAL(10, 2),
  total_price DECIMAL(10, 2),
  rating INT,
  ordered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  phone VARCHAR(255) , 
  address VARCHAR(255) ,
  status VARCHAR(225),
  email VARCHAR(225)
  
)
`);





 // Adjust salt rounds as needed (10–12 is good for most apps)
const saltRounds = 10;

app.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ message: 'Missing fields' });
  }

  // Check if email exists
  db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err });

    if (results.length > 0) {
      return res.status(409).json({ message: 'Email already exists' });
    }

    try {
      // Hash the password
      const hashedPassword = await bcrypt.hash(password, saltRounds);

      // Insert new user
      db.query(
        'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
        [name, email, hashedPassword, role],
        (err, result) => {
          if (err) return res.status(500).json({ message: 'Insert error', error: err });

          res.status(201).json({ message: 'User registered' });
        }
      );
    } catch (hashError) {
      res.status(500).json({ message: 'Error hashing password', error: hashError });
    }
  });
});


/// login
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  const query = 'SELECT * FROM users WHERE email = ?';
  db.query(query, [email], async (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    if (results.length === 0) return res.status(401).json({ message: 'User not found' });

    const user = results[0];
    const match = await bcrypt.compare(password, user.password);

    if (!match) return res.status(401).json({ message: 'Invalid credentials' });

    // Return role and email to the frontend
    return res.json({
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        role: user.role
      }
    });
  });
});


app.post('/verify-user', (req, res) => {
  const { email, role } = req.body;

  if (!email || !role) {
    return res.status(400).json({ message: 'Email and role are required' });
  }

  const query = 'SELECT * FROM users WHERE email = ? AND role = ?';
  db.query(query, [email, role], (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    if (results.length === 0) return res.status(404).json({ message: 'User not found' });

    return res.json({ message: 'User verified' });
  });
});
app.post('/reset-password', async (req, res) => {
  const { email, newPassword } = req.body;

  if (!email || !newPassword) {
    return res.status(400).json({ message: 'Email and new password required' });
  }

  try {
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);
    const query = 'UPDATE users SET password = ? WHERE email = ?';

    db.query(query, [hashedPassword, email], (err, result) => {
      if (err) return res.status(500).json({ message: 'Database error' });

      return res.json({ message: 'Password reset successful' });
    });
  } catch (err) {
    return res.status(500).json({ message: 'Hashing failed', error: err });
  }
});


 

 

// Serve the uploads folder statically  --- to serve profile images
app.use('/upload', express.static(path.join(__dirname, 'upload')));

app.get('/getUserImage', async (req, res) => {
  const { email } = req.query;
  const query = 'SELECT profile_image FROM users WHERE email = ?';

  db.query(query, [email], (err, result) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    if (result.length === 0 || !result[0].profile_image)
      return res.json({ imageUrl: null });

    const imageFileName = result[0].profile_image;
    const imageUrl = `http://localhost:2020/upload/${imageFileName}`;
    res.json({ imageUrl });
  });
});




app.get('/getUsersByRole', (req, res) => {
  const { role } = req.query;
  const query = 'SELECT name, email FROM users WHERE role = ?';

  db.query(query, [role], (err, results) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json(results);
  });
});

  



//for profile {general profile}
// Storage config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'upload/'); // Folder where images go
  },
  filename: function (req, file, cb) {
    const filename = Date.now() + path.extname(file.originalname);
    cb(null, filename);
  }
});
const upload = multer({ storage: storage });
// GET user profile
app.get('/api/profile/:email', (req, res) => {
  const { email } = req.params;
  db.query('SELECT name, email, phone, address, profile_image FROM users WHERE email = ?', [email], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json(result[0]);
  });
});

// POST update user profile
app.post('/api/profile/update', upload.single('photo'), (req, res) => {
  const { name, email, phone, address } = req.body;
  const photo = req.file ? req.file.filename : null;

  let updateQuery;
  let values;

  if (photo) {
    updateQuery = `
      UPDATE users
      SET name = ?, phone = ?, address = ?, profile_image = ?
      WHERE email = ?
    `;
    values = [name, phone, address, photo, email];
  } else {
    updateQuery = `
      UPDATE users
      SET name = ?, phone = ?, address = ?
      WHERE email = ?
    `;
    values = [name, phone, address, email];
  }

  db.query(updateQuery, values, (err, result) => {
    if (err) {
      console.error('DB error:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ message: 'Profile updated successfully' });
  });
});





/* this is for the admin installer */
// CREATE installer
app.post('/installers', upload.single('profile_image'), async (req, res) => {
  const { name, email, password, confirmPassword, phone, address } = req.body;
  const role = 'installer';

  if (!name || !email || !password || !confirmPassword) {
    return res.status(400).json({ error: 'Required fields missing' });
  }

  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const imageName = req.file ? req.file.filename : null;

    const query = `
      INSERT INTO users (name, email, password, phone, address, profile_image, role)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(query, [name, email, hashedPassword, phone, address, imageName, role], (err, result) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ message: 'Installer created successfully' });
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// READ all installers
app.get('/installers', (req, res) => {
  db.query('SELECT * FROM users WHERE role = "installer"', (err, result) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(result);
  });
});

// DELETE installer
app.delete('/installers/:id', (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM users WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json({ message: 'Installer deleted' });
  });
});
/* updating */
app.put('/installers/:id', upload.single('profile_image'), async (req, res) => {
  const { name, email, password, phone, address } = req.body;
  const id = req.params.id;

  try {
    const updates = [];
    const values = [];

    if (name) { updates.push('name = ?'); values.push(name); }
    if (email) { updates.push('email = ?'); values.push(email); }
    if (password) {
      const hashed = await bcrypt.hash(password, 10);
      updates.push('password = ?');
      values.push(hashed);
    }
    if (phone) { updates.push('phone = ?'); values.push(phone); }
    if (address) { updates.push('address = ?'); values.push(address); }
    if (req.file) {
      updates.push('profile_image = ?');
      values.push(req.file.filename);
    }

    if (updates.length === 0) return res.status(400).json({ error: 'No data to update' });

    const sql = `UPDATE users SET ${updates.join(', ')} WHERE id = ?`;
    values.push(id);

    db.query(sql, values, (err, result) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ message: 'Installer updated successfully' });
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});





/* this is for the admin customer */
// CREATE customer
app.post('/customers', upload.single('profile_image'), async (req, res) => {
  const { name, email, password, confirmPassword, phone, address } = req.body;
  const role = 'customer';

  if (!name || !email || !password || !confirmPassword) {
    return res.status(400).json({ error: 'Required fields missing' });
  }

  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const imageName = req.file ? req.file.filename : null;

    const query = `
      INSERT INTO users (name, email, password, phone, address, profile_image, role)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(query, [name, email, hashedPassword, phone, address, imageName, role], (err, result) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ message: 'customer created successfully' });
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// READ all customers
app.get('/customers', (req, res) => {
  db.query('SELECT * FROM users WHERE role = "customer"', (err, result) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(result);
  });
});

// DELETE customer
app.delete('/customers/:id', (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM users WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json({ message: 'customer deleted' });
  });
});
/* updating */
app.put('/customers/:id', upload.single('profile_image'), async (req, res) => {
  const { name, email, password, phone, address } = req.body;
  const id = req.params.id;

  try {
    const updates = [];
    const values = [];

    if (name) { updates.push('name = ?'); values.push(name); }
    if (email) { updates.push('email = ?'); values.push(email); }
    if (password) {
      const hashed = await bcrypt.hash(password, 10);
      updates.push('password = ?');
      values.push(hashed);
    }
    if (phone) { updates.push('phone = ?'); values.push(phone); }
    if (address) { updates.push('address = ?'); values.push(address); }
    if (req.file) {
      updates.push('profile_image = ?');
      values.push(req.file.filename);
    }

    if (updates.length === 0) return res.status(400).json({ error: 'No data to update' });

    const sql = `UPDATE users SET ${updates.join(', ')} WHERE id = ?`;
    values.push(id);

    db.query(sql, values, (err, result) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ message: 'customer updated successfully' });
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});





/* this is for the admin Reseller */
// CREATE Reseller
app.post('/Resellers', upload.single('profile_image'), async (req, res) => {
  const { name, email, password, confirmPassword, phone, address } = req.body;
  const role = 'Reseller';

  if (!name || !email || !password || !confirmPassword) {
    return res.status(400).json({ error: 'Required fields missing' });
  }

  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const imageName = req.file ? req.file.filename : null;

    const query = `
      INSERT INTO users (name, email, password, phone, address, profile_image, role)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(query, [name, email, hashedPassword, phone, address, imageName, role], (err, result) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ message: 'Reseller created successfully' });
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// READ all Resellers
app.get('/Resellers', (req, res) => {
  db.query('SELECT * FROM users WHERE role = "Reseller"', (err, result) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(result);
  });
});

// DELETE Reseller
app.delete('/Resellers/:id', (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM users WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json({ message: 'Reseller deleted' });
  });
});
/* updating */
app.put('/Resellers/:id', upload.single('profile_image'), async (req, res) => {
  const { name, email, password, phone, address } = req.body;
  const id = req.params.id;

  try {
    const updates = [];
    const values = [];

    if (name) { updates.push('name = ?'); values.push(name); }
    if (email) { updates.push('email = ?'); values.push(email); }
    if (password) {
      const hashed = await bcrypt.hash(password, 10);
      updates.push('password = ?');
      values.push(hashed);
    }
    if (phone) { updates.push('phone = ?'); values.push(phone); }
    if (address) { updates.push('address = ?'); values.push(address); }
    if (req.file) {
      updates.push('profile_image = ?');
      values.push(req.file.filename);
    }

    if (updates.length === 0) return res.status(400).json({ error: 'No data to update' });

    const sql = `UPDATE users SET ${updates.join(', ')} WHERE id = ?`;
    values.push(id);

    db.query(sql, values, (err, result) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ message: 'Reseller updated successfully' });
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});





/* this is for the admin dsa */
// CREATE dsa
app.post('/dsas', upload.single('profile_image'), async (req, res) => {
  const { name, email, password, confirmPassword, phone, address } = req.body;
  const role = 'dsa';

  if (!name || !email || !password || !confirmPassword) {
    return res.status(400).json({ error: 'Required fields missing' });
  }

  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const imageName = req.file ? req.file.filename : null;

    const query = `
      INSERT INTO users (name, email, password, phone, address, profile_image, role)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(query, [name, email, hashedPassword, phone, address, imageName, role], (err, result) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ message: 'dsa created successfully' });
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// READ all dsas
app.get('/dsas', (req, res) => {
  db.query('SELECT * FROM users WHERE role = "dsa"', (err, result) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(result);
  });
});

// DELETE dsa
app.delete('/dsas/:id', (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM users WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json({ message: 'dsa deleted' });
  });
});
/* updating */
app.put('/dsas/:id', upload.single('profile_image'), async (req, res) => {
  const { name, email, password, phone, address } = req.body;
  const id = req.params.id;

  try {
    const updates = [];
    const values = [];

    if (name) { updates.push('name = ?'); values.push(name); }
    if (email) { updates.push('email = ?'); values.push(email); }
    if (password) {
      const hashed = await bcrypt.hash(password, 10);
      updates.push('password = ?');
      values.push(hashed);
    }
    if (phone) { updates.push('phone = ?'); values.push(phone); }
    if (address) { updates.push('address = ?'); values.push(address); }
    if (req.file) {
      updates.push('profile_image = ?');
      values.push(req.file.filename);
    }

    if (updates.length === 0) return res.status(400).json({ error: 'No data to update' });

    const sql = `UPDATE users SET ${updates.join(', ')} WHERE id = ?`;
    values.push(id);

    db.query(sql, values, (err, result) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ message: 'dsa updated successfully' });
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});





 


 


/* product management */
app.post('/create_product', upload.single('image'), (req, res) => {
  const { name, description, price, discount } = req.body;
  const image = req.file?.filename || null;
  db.query('INSERT INTO products (name, image, description, price, discount) VALUES (?, ?, ?, ?, ?)',
    [name, image, description, price, discount],
    (err, result) => {
      if (err) return res.status(500).json({ error: 'DB Error' });
      res.json({ message: 'Product created', id: result.insertId });
    });
});

// READ
app.get('/display_product', (req, res) => {
  db.query('SELECT * FROM products ORDER BY created_at DESC', (err, results) => {
    if (err) return res.status(500).json({ error: 'DB Error' });
    res.json(results);
  });
});

// DELETE
app.delete('/deleteproduct/:id', (req, res) => {
  db.query('DELETE FROM products WHERE id = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json({ error: 'DB Error' });
    res.json({ message: 'Product deleted' });
  });
});

// UPDATE
app.put('/updateproduct/:id', upload.single('image'), (req, res) => {
  const { name, description, price, discount } = req.body;
  const image = req.file?.filename;
  const fields = [name, description, price, discount];
  let query = 'UPDATE products SET name=?, description=?, price=?, discount=?';
  if (image) {
    query += ', image=?';
    fields.push(image);
  }
  query += ' WHERE id=?';
  fields.push(req.params.id);

  db.query(query, fields, (err) => {
    if (err) return res.status(500).json({ error: 'DB Error' });
    res.json({ message: 'Product updated' });
  });
});





/* announcement page */
app.get('/announcements', (req, res) => {
  db.query(`SELECT * FROM announcements ORDER BY id DESC`, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

app.get('/announcement/:id', (req, res) => {
  const id = req.params.id;

  db.query(
    `SELECT * FROM announcements WHERE id = ?`,
    [id],
    (err, announcementResult) => {
      if (err) return res.status(500).json(err);

      if (announcementResult.length === 0)
        return res.status(404).json({ message: 'Announcement not found' });

      db.query(
        `SELECT * FROM comments WHERE announcement_id = ? ORDER BY id DESC`,
        [id],
        (err, commentResult) => {
          if (err) return res.status(500).json(err);

          db.query(
            `SELECT 
              SUM(CASE WHEN reaction = 'like' THEN 1 ELSE 0 END) AS likeCount,
              SUM(CASE WHEN reaction = 'dislike' THEN 1 ELSE 0 END) AS dislikeCount
            FROM reactions WHERE announcement_id = ?`,
            [id],
            (err, reactionCounts) => {
              if (err) return res.status(500).json(err);

              const stats = {
                like: reactionCounts[0].likeCount || 0,
                dislike: reactionCounts[0].dislikeCount || 0,
              };

              res.json({
                announcement: announcementResult[0],
                comments: commentResult,
                reactions: stats,
              });
            }
          );
        }
      );
    }
  );
});

app.post('/announcement', (req, res) => {
  const { title, content } = req.body;
  db.query(
    `INSERT INTO announcements (title, content) VALUES (?, ?)`,
    [title, content],
    (err) => {
      if (err) return res.status(500).json(err);
      res.sendStatus(200);
    }
  );
});

app.post('/announcement/:id/comment', (req, res) => {
  const { name, comment } = req.body;
  const announcement_id = req.params.id;

  db.query(
    `INSERT INTO comments (announcement_id, name, comment) VALUES (?, ?, ?)`,
    [announcement_id, name, comment],
    (err) => {
      if (err) return res.status(500).json(err);
      res.sendStatus(200);
    }
  );
});

app.post('/announcement/:id/react', (req, res) => {
  const { user_name, reaction } = req.body;
  const announcement_id = req.params.id;

  // Check existing reaction
  db.query(
    `SELECT * FROM reactions WHERE announcement_id = ? AND user_name = ?`,
    [announcement_id, user_name],
    (err, results) => {
      if (err) return res.status(500).json(err);

      if (results.length === 0) {
        db.query(
          `INSERT INTO reactions (announcement_id, user_name, reaction) VALUES (?, ?, ?)`,
          [announcement_id, user_name, reaction],
          (err) => {
            if (err) return res.status(500).json(err);
            res.sendStatus(200);
          }
        );
      } else {
        const current = results[0].reaction;
        if (current === reaction) {
          // Remove reaction
          db.query(
            `DELETE FROM reactions WHERE id = ?`,
            [results[0].id],
            (err) => {
              if (err) return res.status(500).json(err);
              res.sendStatus(200);
            }
          );
        } else {
          // Update reaction
          db.query(
            `UPDATE reactions SET reaction = ? WHERE id = ?`,
            [reaction, results[0].id],
            (err) => {
              if (err) return res.status(500).json(err);
              res.sendStatus(200);
            }
          );
        }
      }
    }
  );
});




/* this is for general installer */
app.get('/general_installer/users', (req, res) => {
  db.query('SELECT name, email, profile_image, phone, address FROM users WHERE role = "installer" ORDER BY name ASC', (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

// Express route (Node.js)
app.get('/get_phone_by_email', (req, res) => {
  const email = req.query.email;
  if (!email) return res.status(400).json({ error: 'Email is required' });

  const sql = 'SELECT phone FROM users WHERE email = ?'; // Change 'users' to your correct table
  db.query(sql, [email], (err, result) => {
    if (err) {
      console.error('DB error:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    if (result.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json({ phone: result[0].phone });
  });
});




/* product page for customer, dsa etc */
app.get('/general_products', (req, res) => {
  db.query('SELECT * FROM products', (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

// Your Express route
app.post('/place_order', (req, res) => {
  //const cart = req.body.cart;
  const userEmail = req.cookies.user;
  const { cart, user } = req.body;

  if (!userEmail) {
    return res.status(401).json({ message: 'Unauthorized: No user cookie' });
  }

  // Step 1: Get user details
  const userQuery = `SELECT name, phone, role, address, email FROM users WHERE email = ? LIMIT 1`;

  db.query(userQuery, [userEmail], (err, results) => {
    if (err) {
      console.error('Error fetching user info:', err);
      return res.status(500).json({ message: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    const { name, phone, address , email } = results[0];

    // Step 2: Insert orders
    const orderQuery = `
      INSERT INTO orders (
        product_id, product_name, qty, user_name, phone, address,
        price, total_price, rating, status, email
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    let errorCount = 0;

    cart.forEach(item => {
      const values = [
        item.id,
        item.name,
        item.qty,
        name,
        phone,
        address,
        item.price,
        item.qty * item.price,
        item.rating,
        'Pending', // default status
        email
      ];

      db.query(orderQuery, values, (err) => {
        if (err) {
          console.error('Error inserting order:', err);
          errorCount++;
        }
      });
    });

    if (errorCount === 0) {
      res.send({ message: 'Order saved successfully' });
    } else {
      res.status(500).json({ message: 'Some orders failed to save' });
    }
  });
});
app.get('/get_orders_by_user', (req, res) => {
  const { email } = req.query;
  db.query('SELECT * FROM orders WHERE email = ? ORDER BY ordered_at DESC', [email], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result);
  });
});






/* admin order {history} */
app.get('/get_orders', (req, res) => {
  db.query('SELECT * FROM orders ORDER BY ordered_at DESC', (err, results) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json(results);
  });
});

// Update status
app.post('/update_order_status', (req, res) => {
  const { id, status } = req.body;
  db.query('UPDATE orders SET status = ? WHERE id = ?', [status, id], (err) => {
    if (err) return res.status(500).json({ error: 'Failed to update status' });
    res.json({ message: 'Status updated successfully' });
  });
});







/* graph */
// In your Express app
// Express backend route
// Backend GET route with optional start_date and end_date
app.get('/admin_sales_data', (req, res) => {
  const { filter, start_date, end_date } = req.query;
  let groupBy;

  if (filter === 'day') groupBy = `DATE(ordered_at)`;
  else if (filter === 'week') groupBy = `YEARWEEK(ordered_at)`;
  else groupBy = `MONTH(ordered_at)`;

  let dateCondition = '';
  if (start_date && end_date) {
    dateCondition = `AND ordered_at BETWEEN '${start_date}' AND '${end_date}'`;
  } else {
    if (filter === 'day') {
      dateCondition = `AND ordered_at >= CURDATE()`;
    } else if (filter === 'week') {
      dateCondition = `AND YEARWEEK(ordered_at) = YEARWEEK(CURDATE())`;
    } else {
      dateCondition = `AND MONTH(ordered_at) = MONTH(CURDATE())`;
    }
  }

  const sql = `
    SELECT ${groupBy} AS label,
           SUM(total_price) AS total_sales,
           COUNT(*) AS total_orders
    FROM orders
    WHERE 1=1 ${dateCondition}
    GROUP BY label
    ORDER BY ordered_at DESC
    LIMIT 10
  `;

  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ error: err });

    const formatted = results.map(r => ({
      label: r.label ? r.label.toString() : 'N/A',
      total_sales: Number(r.total_sales || 0),
      total_orders: Number(r.total_orders || 0),
    }));

    res.json({ current: formatted });
  });
});




// Start server
app.listen(2020, () => {
  console.log('Server running on http://localhost:2020');
});



